from Packets.Commands.Server.LogicBoxDataCommand import LogicBoxDataCommand
from Packets.Messages.Server.OutOfSyncMessage import OutOfSyncMessage
from Database.DatabaseManager import DataBase
from Logic.Shop import Shop
from Packets.Commands.Server.ShopResponse import ShopResponse
from Packets.Commands.Server.Add import LogicBuySkinOrBrawler

from Utils.Reader import BSMessageReader
import random

class LogicPurchaseOfferCommand(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()
        self.offer_index = self.read_Vint()


    def process(self):
        Shop.loadOffers(self)
        brawler = Shop.offers[self.offer_index]["BrawlerID"]
        offers = self.offers
        id = Shop.offers[self.offer_index]['ID']
        type = Shop.offers[self.offer_index]['ShopType']
        cost = Shop.offers[self.offer_index]['Cost']

        def res(type):
            if type == 0:
                newGems = self.player.gems - cost
                self.player.gems = newGems
                DataBase.replaceValue(self, 'gems', newGems)
            elif type == 1:
            	newGold = self.player.gold - cost
            	self.player.gold = newGold
            	DataBase.replaceValue(self, 'gold', newGold)
            elif type == 3:
                newStarPoints = self.player.star_points - cost
                self.player.star_points = newStarPoints
                DataBase.replaceValue(self, 'starpoints', newStarPoints)

        if id in [0, 6, 10, 14]:

            if id in [0, 6]:
                self.player.box_id = 5

            elif id == 14:
                self.player.box_id = 4

            elif id == 10:
                self.player.box_id = 3

            res(type)

            LogicBoxDataCommand(self.client, self.player).send()
            Shop.UpdateOfferData(self, self.offer_index)
             
        elif id == 1:
        	ShopResponse(self.client, self.player, {"id": 7, "name": "gold"}, self.player.gold + Shop.offers[self.offer_index]["Multiplier"], Shop.offers[self.offer_index]["Multiplier"]).send()
        	gold = self.player.gold + Shop.offers[self.offer_index]["Multiplier"]
        	DataBase.replaceValue(self, 'gold', gold)
        	Shop.offers[self.offer_index]['Cost'] = 100
        	Shop.UpdateOfferData(self, self.offer_index)
        	 
        elif id == 4:
        	LogicBuySkinOrBrawler(self.client, self.player, 9, Shop.offers[self.offer_index]['SkinID']).send()
        	self.player.SkinsUnlock.append(Shop.offers[self.offer_index]['SkinID'])
        	DataBase.replaceValue(self, 'SkinsUnlock', self.player.SkinsUnlock)
        	Shop.offers[self.offer_index]['Cost'] = 100
        	Shop.UpdateOfferData(self, self.offer_index)
        	 
        	 
        elif id == 8:
        	ShopResponse(self.client, self.player, {"id": 6, "name": "brawlersUpgradePoints", "scid": Shop.offers[self.offer_index]["BrawlerID"]}, self.player.brawlers_upgradium,Shop.offers[self.offer_index]["Multiplier"]).send()
        	self.player.brawlers_upgradium[str(Shop.offers[self.offer_index]["BrawlerID"])] + Shop.offers[self.offer_index]["Multiplier"]
        	DataBase.replaceValue(self, 'brawlersUpgradePoints', self.player.brawlers_upgradium)
        	Shop.offers[self.offer_index]['Cost'] = 100
        	Shop.UpdateOfferData(self, self.offer_index)
        	 
        elif id == 9:
        	ShopResponse(self.client, self.player, {"id": 2, "name": "tokensdoubler"}, self.player.tokensdoubler + Shop.offers[self.offer_index]["Multiplier"], Shop.offers[self.offer_index]["Multiplier"]).send()
        	tokens = self.player.tokensdoubler + Shop.offers[self.offer_index]["Multiplier"]
        	DataBase.replaceValue(self, 'tokensdoubler', tokens)
        	Shop.offers[self.offer_index]['Cost'] = 100
        	Shop.UpdateOfferData(self, self.offer_index)
        	 
        elif id == 16:
        	ShopResponse(self.client, self.player, {"id": 8, "name": "gems"}, self.player.gems + Shop.offers[self.offer_index]["Multiplier"], Shop.offers[self.offer_index]["Multiplier"]).send()
        	gems = self.player.gems + Shop.offers[self.offer_index]["Multiplier"]
        	DataBase.replaceValue(self, 'gems', gems)
        	Shop.offers[self.offer_index]['Cost'] = 100
        	Shop.UpdateOfferData(self, self.offer_index)
        	 
        elif id == 3:
        	LogicBuySkinOrBrawler(self.client, self.player, 1, Shop.offers[self.offer_index]['BrawlerID']).send()
        	Shop.offers[self.offer_index]['Cost'] = 100
        	Shop.UpdateOfferData(self, self.offer_index)
        	 
        elif id == 24:
        	LogicBuySkinOrBrawler(self.client, self.player, 9, Shop.offers[self.offer_index]['SkinID']).send()
        	self.player.SkinsUnlock.append(Shop.offers[self.offer_index]['SkinID'])
        	DataBase.replaceValue(self, 'SkinsUnlock', self.player.SkinsUnlock)
        	Shop.offers[self.offer_index]['Cost'] = 100
        	Shop.UpdateOfferData(self, self.offer_index)
