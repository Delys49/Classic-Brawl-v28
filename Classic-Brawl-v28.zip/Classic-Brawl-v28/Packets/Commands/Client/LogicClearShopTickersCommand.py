from Files.CsvLogic.Cards import Cards
from Files.CsvLogic.Characters import Characters

from Utils.Reader import BSMessageReader

class LogicClearShopTickersCommand(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        pass

    def process(self):
        pass