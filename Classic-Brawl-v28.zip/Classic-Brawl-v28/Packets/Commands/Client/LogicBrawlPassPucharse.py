from Database.DatabaseManager import DataBase

from Utils.Reader import BSMessageReader

class BP(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
    	pass
    def process(self):
        gems = self.player.gems - 169
        bp = self.player.BrawlPass = True
        
        DataBase.replaceValue(self, 'gems', gems)
        DataBase.replaceValue(self, 'BrawlPass', bp)
        