import time

class EventSlots:
    Timer = 86399
        # Status = [3 = Nothing, 2 = Star Token, 1 = New Event]

#    1 = Energy Drink
#    2 = Angry Robo
#    3 = Meteor Shower
#    4 = Graveyard Shift
#    5 = Healing Mushrooms
#   8 = Boss Lasers
#   9 = Boss Chain Lighting
#   10 = Boss Rockets
#  11 = Ship Tilting
    maps = [

        {
            'ID': 7,
            'Status': 2,
            'Ended': False,
            'Modifier': [0, 0, 0, 0, 0, 0],
            'Tokens': 10
        },

        {
            'ID': 32,
            'Status': 2,
            'Ended': False,
            'Modifier': [0, 0, 0, 0, 0, 0],
            'Tokens': 10
        },

        {
            'ID': 17,
            'Status': 2,
            'Ended': False,
            'Modifier': [0, 0, 0, 0, 0, 0],
            'Tokens': 10
        },

        {
            'ID': 0,
            'Status': 2,
            'Ended': False,
            'Modifier': [0, 0, 0, 0, 0, 0],
            'Tokens': 10
        },

        {
            'ID': 269,
            'Status': 2,
            'Ended': False,
            'Modifier': [0, 0, 0, 0, 0, 0],
            'Tokens': 10
        },

        {
            'ID': 24,
            'Status': 2,
            'Ended': False,
            'Modifier': [0, 0, 0, 0, 0, 0],
            'Tokens': 10
        },

        {
            'ID': 21,
            'Status': 2,
            'Ended': False,
            'Modifier': [0, 0, 0, 0, 0, 0],
            'Tokens': 2
        },

        {
            'ID': 97,
            'Status': 2,
            'Ended': False,
            'Modifier': [0, 0, 0, 0, 0, 0],
            'Tokens': 10
        },
        
        {
            'ID': 56, #power play
            'Status': 2,
            'Ended': False,
            'Modifier': [0, 0, 0, 0, 0, 0],
            'Tokens': 0
        },
    ]